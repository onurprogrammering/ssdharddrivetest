//
//  Furniture_appApp.swift
//  Furniture_app
//
//  Created by Abu Anwar MD Abdullah on 14/2/21.
//

import SwiftUI

@main
struct Furniture_appApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
